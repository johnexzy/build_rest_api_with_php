<!DOCTYPE html>
<html lang="en">

<?php
require 'bootstrap.php';
use Src\Layout\NavBarClass;
use Src\Layout\FooterClass;
use Src\Layout\CarouselClass;


$footer = new FooterClass();
$navbar = new NavBarClass("./", null);
$carousel = new CarouselClass();
echo($navbar->returnNavLayout());

?>

    <!-- End Navbar -->


    <!--------------------------------------
HEADER
--------------------------------------->
    <div class="container">
        <?php
            echo($carousel->returnCarousel());
        ?>

    </div>
    <!-- End Header -->


    <!--------------------------------------
MAIN
--------------------------------------->

    <div class="container pt-4 pb-4">
        <div class="row">
            <div class="col-lg-6">
                <div class="card border-0 mb-4 box-shadow h-xl-300">
                    <div style="background-image: url(./assets/img/demo/1.jpg); height: 150px;    background-size: cover;    background-repeat: no-repeat;"></div>
                    <div class="card-body px-0 pb-0 d-flex flex-column align-items-start">
                        <h2 class="h4 font-weight-bold">
                            <a class="text-dark" href="./article.html">Brain Stimulation Relieves Depression Symptoms</a>
                        </h2>
                        <p class="card-text">
                            Researchers have found an effective target in the brain for electrical stimulation to improve mood in people suffering from depression.
                        </p>
                        <div>
                            <small class="d-block"><a class="text-muted" href="./author.html">Favid Rick</a></small>
                            <small class="text-muted">Dec 12 &middot; 5 min read</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="flex-md-row mb-4 box-shadow h-xl-300">
                    <div class="mb-3 d-flex align-items-center">
                        <img height="80" src="./assets/img/demo/blog4.jpg">
                        <div class="pl-3">
                            <h2 class="mb-2 h6 font-weight-bold">
                                <a class="text-dark" href="./article.html">Nasa's IceSat space laser makes height maps of Earth</a>
                            </h2>
                            <div class="card-text text-muted small">
                                Jake Bittle in LOVE/HATE
                            </div>
                            <small class="text-muted">Dec 12 &middot; 5 min read</small>
                        </div>
                    </div>
                    <div class="mb-3 d-flex align-items-center">
                        <img height="80" src="./assets/img/demo/blog5.jpg">
                        <div class="pl-3">
                            <h2 class="mb-2 h6 font-weight-bold">
                                <a class="text-dark" href="./article.html">Underwater museum brings hope to Lake Titicaca</a>
                            </h2>
                            <div class="card-text text-muted small">
                                Jake Bittle in LOVE/HATE
                            </div>
                            <small class="text-muted">Dec 12 &middot; 5 min read</small>
                        </div>
                    </div>
                    <div class="mb-3 d-flex align-items-center">
                        <img height="80" src="./assets/img/demo/blog6.jpg">
                        <div class="pl-3">
                            <h2 class="mb-2 h6 font-weight-bold">
                                <a class="text-dark" href="./article.html">Sun-skimming probe starts calling home</a>
                            </h2>
                            <div class="card-text text-muted small">
                                Jake Bittle in LOVE/HATE
                            </div>
                            <small class="text-muted">Dec 12 &middot; 5 min read</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-between">
            <div class="col-md-8">
                <h5 class="font-weight-bold spanborder"><span>All Stories</span></h5>
                <div class="mb-3 d-flex justify-content-between">
                    <div class="pr-3">
                        <h2 class="mb-1 h4 font-weight-bold">
                            <a class="text-dark" href="./article.html">Nearly 200 Great Barrier Reef coral species also live in the deep sea</a>
                        </h2>
                        <p>
                            There are more coral species lurking in the deep ocean that previously thought.
                        </p>
                        <div class="card-text text-muted small">
                            Jake Bittle in SCIENCE
                        </div>
                        <small class="text-muted">Dec 12 &middot; 5 min read</small>
                    </div>
                    <img height="120" src="./assets/img/demo/blog8.jpg">
                </div>
                <div class="mb-3 d-flex justify-content-between">
                    <div class="pr-3">
                        <h2 class="mb-1 h4 font-weight-bold">
                            <a class="text-dark" href="./article.html">East Antarctica's glaciers are stirring</a>
                        </h2>
                        <p>
                            Nasa says it has detected the first signs of significant melting in a swathe of glaciers in East Antarctica.
                        </p>
                        <div class="card-text text-muted small">
                            Jake Bittle in SCIENCE
                        </div>
                        <small class="text-muted">Dec 12 &middot; 5 min read</small>
                    </div>
                    <img height="120" src="./assets/img/demo/1.jpg">
                </div>
                <div class="mb-3 d-flex justify-content-between">
                    <div class="pr-3">
                        <h2 class="mb-1 h4 font-weight-bold">
                            <a class="text-dark" href="./article.html">50 years ago, armadillos hinted that DNA wasn’t destiny</a>
                        </h2>
                        <p>
                            Nasa says it has detected the first signs of significant melting in a swathe of glaciers in East Antarctica.
                        </p>
                        <div class="card-text text-muted small">
                            Jake Bittle in SCIENCE
                        </div>
                        <small class="text-muted">Dec 12 &middot; 5 min read</small>
                    </div>
                    <img height="120" src="./assets/img/demo/5.jpg">
                </div>
            </div>
            <div class="col-md-4 pl-4">
                <h5 class="font-weight-bold spanborder"><span>Popular</span></h5>
                <ol class="list-featured">
                    <li>
                        <span>
				<h6 class="font-weight-bold">
				<a href="./article.html" class="text-dark">Did Supernovae Kill Off Large Ocean Animals?</a>
				</h6>
				<p class="text-muted">
					Jake Bittle in SCIENCE
				</p>
				</span>
                    </li>
                    <li>
                        <span>
				<h6 class="font-weight-bold">
				<a href="./article.html" class="text-dark">Humans Reversing Climate Clock: 50 Million Years</a>
				</h6>
				<p class="text-muted">
					Jake Bittle in SCIENCE
				</p>
				</span>
                    </li>
                    <li>
                        <span>
				<h6 class="font-weight-bold">
				<a href="./article.html" class="text-dark">Unprecedented Views of the Birth of Planets</a>
				</h6>
				<p class="text-muted">
					Jake Bittle in SCIENCE
				</p>
				</span>
                    </li>
                    <li>
                        <span>
				<h6 class="font-weight-bold">
				<a href="./article.html" class="text-dark">Effective New Target for Mood-Boosting Brain Stimulation Found</a>
				</h6>
				<p class="text-muted">
					Jake Bittle in SCIENCE
				</p>
				</span>
                    </li>
                </ol>
            </div>
        </div>
    </div>

    <!--------------------------------------
FOOTER
--------------------------------------->
    <?php
        
        echo($footer->returnFooterLayout());
    ?>
    <!-- End Footer -->

    <!--------------------------------------
JAVASCRIPTS
--------------------------------------->
    <script src="./assets/js/vendor/jquery.min.js" type="text/javascript"></script>
    <script src="./assets/js/vendor/popper.min.js" type="text/javascript"></script>
    <script src="./assets/js/vendor/bootstrap.min.js" type="text/javascript"></script>
    <script src="./assets/js/functions.js" type="text/javascript"></script>
    <script>
        $('.carousel').on('slide.bs.carousel', function(event) {
            var height = $(event.relatedTarget).height();
            var $innerCarousel = $(event.target).find('.carousel-inner');
            $innerCarousel.animate({
                height: height
            });
        });
    </script>
</body>

</html>